
package servlets;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import utils.DateUtils;
import utils.Ldap;
import utils.Rserve;
import utils.Storage;
import constants.Init;

public class UploadServlet extends HttpServlet {
	
	private static boolean rserveStarted = false;
	private static boolean rserveUploading = false;

	private final Logger LOG = Logger.getLogger(UploadServlet.class);

	private static final long serialVersionUID = 1L;

	private static final String DATA_DIRECTORY = Init.DATA_DIRECTORY;
	private static final int MAX_MEMORY_SIZE = Init.MAX_MEMORY_SIZE;
	private static final int MAX_REQUEST_SIZE = Init.MAX_REQUEST_SIZE;
	private static final String STATUS_PAGE = Init.STATUS_PAGE;


	private Storage storage;

	// date & time vars
	private long start;

	private Rserve rserve;
	
	private static long rserveStartTime;

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		System.out.println("ONCE.........................");
		try {
			//startRserver();
		} catch (Exception e) {
			rserveStarted = false;
			e.printStackTrace();
		}
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		Init.SERVLET_CONTEXT_PATH = Init.SCRIPT_DATA_DIRECTORY;
		Init.CONTEXT_PATH=getServletContext().getRealPath("database.properties");
		try { 
			getServletContext().getRequestDispatcher(STATUS_PAGE).forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		if(request.getSession().getAttribute("userName")==null){
			response.sendRedirect("./");
			return;
		}
		
		long threadId = Thread.currentThread().getId();
		System.out.println("threadId "+threadId);
		request.getSession().setAttribute("threadId", threadId);
		
		File saveFile = null;
		String filePath = null;
		String fileName = null;
		String outputDir = Init.BASE_DIRECTORY;
		/*try {
			startRserver();
		} catch (InterruptedException e) {
			rserveStarted = false;
			e.printStackTrace();
		}*/

		storage = new Storage();
		rserve = new Rserve();

		String outpFileName="temp";
		
		// Check that we have a file upload request
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);

		if (!isMultipart) {
			return;
		}

		// Create a factory for disk-based file items
		DiskFileItemFactory factory = new DiskFileItemFactory();

		// Sets the size threshold beyond which files are written directly to disk
		factory.setSizeThreshold(MAX_MEMORY_SIZE);

		// Sets the directory used to temporarily store files that are larger
		// than the configured size threshold. We use temporary directory for java
		factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

		// constructs the folder where uploaded file will be stored
		String uploadFolder = DATA_DIRECTORY;

		// Create a new file upload handler
		ServletFileUpload upload = new ServletFileUpload(factory);

		// Set overall request size constraint
		upload.setSizeMax(MAX_REQUEST_SIZE);
		// Parse the request
		List<FileItem> multiparts =null;
		//final List<Integer> ids = new ArrayList<>();
		boolean flag=false;
		String scriptName="";
		String batchId="";
		String fileBasePath="";
		try {
			
			multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
						
			//for getting R-script name
			for (FileItem item : multiparts) {
				if (item.isFormField()) {
					if(item.getFieldName().equals("scriptName")){
						System.out.println("Script: "+item.getString());
						scriptName=item.getString();
						Init.RSOURCEFILE = "source('"+(Init.SCRIPT_DATA_DIRECTORY+ File.separator).replace("\\", "\\\\")+item.getString()+"')".toString();
						
						System.out.println("Source for R ->  "+Init.RSOURCEFILE);
					}else if(item.getFieldName().equals("filename")){
						outpFileName=item.getString();
					}	
				} 
			}
			
			
			//Make folder
			 fileBasePath = outputDir + File.separator + outpFileName;
			 uploadFolder = fileBasePath+File.separator+"Input";
			File uploadedFileDir = new File(uploadFolder);
		    if(!uploadedFileDir.exists())
		    	FileUtils.forceMkdir(uploadedFileDir);
		    
		    outputDir=fileBasePath+File.separator+"Output";
		    File outputFile = new File(outputDir);
		    if(!outputFile.exists())
		    	FileUtils.forceMkdir(outputFile);
		    
			// main proccess
			for (FileItem item : multiparts) {
					synchronized (this) {
					
					if (!item.isFormField()) {
						fileName = new File(item.getName()).getName();
						String inputFilePath = uploadFolder + File.separator + fileName;
					    File uploadedFile = new File(inputFilePath);
						//uploadedFiles.add(uploadedFile);
						System.out.println(inputFilePath);
						// saves the file to upload directory
						item.write(uploadedFile);
	
						start = DateUtils.getTime();
	
					}
				}
			}	
			
			start = DateUtils.getTime();
			Object[] dataForSaving = { outpFileName, scriptName, start, null,
					"In Progress", "",request.getSession().getAttribute("userName") };
			storage.storeDbData(dataForSaving);
			batchId=outpFileName;
		
			filePath = fileBasePath+File.separator+"temp";
			File filePathDir = new File(filePath);
		    if(!filePathDir.exists())
		    	FileUtils.forceMkdir(filePathDir);
		    
		    FileUtils.writeStringToFile(new File(Init.SCRIPT_DATA_DIRECTORY+File.separator+"awk_name.txt"), outpFileName);
			
		    if(scriptName.equals("Dynamic_Inquiry_Attributes_Post_Acq.R")){
				String path =uploadFolder;
				String[] parameter={"/home/ubuntu/data/Project/scripts/Dynamic_awk_variable_generation.sh",path};
				ProcessBuilder pb2=new ProcessBuilder(parameter);
				System.out.println("Dynamic_awk_variable_generation.sh is running");
				try {
					Process script_exec = pb2.start();
					script_exec.waitFor();
					StringBuffer out=new StringBuffer();
					BufferedReader bufReader=new BufferedReader(new InputStreamReader(script_exec.getInputStream()));
					String line="";
					while((line= bufReader.readLine())!=null){
						System.out.println(line);
						out.append(line+"\n");
						
					}
					System.out.println("Awk variable generated....");
					System.out.println("Dynamic_awk_variable_generation.sh is done");
				}catch(Exception e) {
					System.out.println("Exception while processing background job "+e.getMessage());
				}
			
			}
			
			if(scriptName.equals("Dynamic_Account_Attr_Post_Acq.R")){
				String path =uploadFolder;
				String[] parameter={"/home/ubuntu/data/Project/scripts/newawk.sh",path};
				ProcessBuilder pb2=new ProcessBuilder(parameter);
				
				try {
					Process script_exec = pb2.start();
					script_exec.waitFor();
					StringBuffer out=new StringBuffer();
					BufferedReader bufReader=new BufferedReader(new InputStreamReader(script_exec.getInputStream()));
					String line="";
					while((line= bufReader.readLine())!=null){
						System.out.println(line);
						out.append(line+"\n");
						
					}
					System.out.println("Awk variable generated....");
				}catch(Exception e) {
					System.out.println("Exception while processing background job "+e.getMessage());
				}
			
			}
			
			FileUtils.writeStringToFile(new File(Init.SCRIPT_DATA_DIRECTORY+File.separator+"batch_name.txt"), outpFileName);
			
			fileName=multiparts.get(0).getString().replace(".R", "");
			System.out.println(fileName+" started");
			rserve.rEvent(outpFileName, scriptName ,start);
			System.out.println(fileName+" End");
				     
		} catch (FileUploadException ex) {
			LOG.error(ex);
			throw new ServletException(ex);
		} catch (Exception ex) {
			LOG.error(ex);
			flag=true;
			System.out.println("Error flag true");
			throw new ServletException(ex);
		}finally{
			
			if(flag){
				Object[] dataForSaving = {batchId ,scriptName, start, start,
					"Error", "-" };
			
				storage.updateDbData(dataForSaving);
			}
			  try {
				stopRserver();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  if(flag){
				// clean input data directory
					FileUtils.cleanDirectory(new File(uploadFolder));
					// clean temp folder
					FileUtils.cleanDirectory(new File(filePath));
					// clean output folder
					FileUtils.cleanDirectory(new File(outputDir));
					
					FileUtils.deleteDirectory(new File(fileBasePath));
					
					System.out.println("Files deleted");
				  response.sendRedirect("/RserveProjectWeb/");
				  return;
				  
			  }
		}
		
		FileUtils.writeStringToFile(new File(Init.SCRIPT_DATA_DIRECTORY+File.separator+"merge_name.txt"), outpFileName);
		
		
		if(scriptName.equals("Dynamic_Inquiry_Attributes_Post_Acq.R")) {
			System.out.println("System is about merge files");
			try {
				System.out.println("Dynamic_Post_Acq_Inquiry_Attributes_Step2.r is running");
				Process p = Runtime.getRuntime().exec("Rscript /home/ubuntu/data/Project/scripts/Dynamic_Post_Acq_Inquiry_Attributes_Step2.R");
				p.waitFor();
				System.out.println("Dynamic_Post_Acq_Inquiry_Attributes_Step2.R done");
			}catch(Exception e) {
				System.out.println("Exception while at merge "+e.getMessage());
			}
			System.out.println("merge is done ");
		}
		
		if(scriptName.equals("Dynamic_Account_Attr_Post_Acq.R")){
			System.out.println("System is about merge files");
			try {
				Process p = Runtime.getRuntime().exec("Rscript /home/ubuntu/data/Project/scripts/newpost.r");
				p.waitFor();
				
			}catch(Exception e) {
				System.out.println("Exception while at merge "+e.getMessage());
			}
			System.out.println("merge is done ");
		}
			
		String outputFile = outputDir + File.separator+fileName+".csv";
		saveFile=new File(outputFile);
		if(saveFile.exists()){
			FileInputStream saveFileStream=new FileInputStream(saveFile);
		
		 ServletContext context = getServletContext();
         
        // gets MIME type of the file
        String mimeType = context.getMimeType(filePath);
        if (mimeType == null) {        
            // set to binary type if MIME mapping not found
            mimeType = "application/octet-stream";
        }
        System.out.println("MIME type: " + mimeType);
         
        
        // modifies response
        response.setContentType(mimeType);
        response.setContentLength((int) saveFile.length());
		
        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=\"%s\"", saveFile.getName().substring(0, saveFile.getName().indexOf('.'))+"_"+outpFileName+".csv");
        response.setHeader(headerKey, headerValue);

        
        // obtains response's output stream
        OutputStream outStream = response.getOutputStream();
         
        byte[] buffer = new byte[4096];
        int bytesRead = -1;
         
        while ((bytesRead = saveFileStream.read(buffer)) != -1) {
            outStream.write(buffer, 0, bytesRead);
        }
         
        saveFileStream.close();
        outStream.close();
      
        //saveFile.delete();
		}else{
			flag=true;
		}
		
		// clean input data directory
		FileUtils.cleanDirectory(new File(uploadFolder));
		// clean temp folder
		FileUtils.cleanDirectory(new File(filePath));
		// clean output folder
		FileUtils.cleanDirectory(new File(outputDir));
		FileUtils.deleteDirectory(new File(fileBasePath));
		System.out.println("Files deleted");
	
	}

	public   void startRserver() throws IOException, InterruptedException {
		if (!rserveStarted) {
			System.out.println("Starting Rserve");
			rserveStartTime = new Date().getTime();
			rserveStarted = true;
			Properties properties=new Properties();
			InputStream input=new FileInputStream(getServletContext().getRealPath("/r.properties"));
			properties.load(input);
		
			// Ubuntu
			// Runtime.getRuntime().exec(properties.getProperty("Path.Ubuntu.RPATH"));	
		
			// Redhat
			   Runtime.getRuntime().exec(properties.getProperty("Path.Redhat.RPATH"));	
			Thread.sleep(5000);
			}
	}

	public static void stopRserver() throws IOException, InterruptedException {
		if (!rserveUploading) {
			rserveStarted = false;
			System.out.println("Stopping Rserve");
	
		//  Ubuntu
		//	Runtime.getRuntime().exec(Init.RKILLCMD);
		
			Thread.sleep(5000);
		}
	}

	public static void checkThreads() throws IOException, InterruptedException {
		Set<Thread> threadSet;
		while (true) {
			threadSet = Thread.getAllStackTraces().keySet();
			int count = 0;
			for (Thread t : threadSet) {
				if (t.getName().contains("Uploading")) {
					System.out.println(t.getName()+" "+t.getState()+" "+t.isAlive());
					count = count + 1;
				}
			}
			
			System.out.println("Threads: "+count);
			long diffTime = new Date().getTime() - rserveStartTime;
			if (count==0 && rserveStarted && diffTime > 15000) {
				rserveUploading = false;
				stopRserver();
			}
			Thread.sleep(5000);
		}
	}
}