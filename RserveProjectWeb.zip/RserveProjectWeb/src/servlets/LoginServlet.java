package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import utils.Ldap;

public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		doGet(request,  response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		if(request.getParameter("action")!=null && request.getParameter("action").equals("logout")){
			request.getSession().invalidate();
			response.sendRedirect("./");
			return;
		}
			
		final String user = request.getParameter("username");
		final String password = request.getParameter("password");		
		
		if(Ldap.validate(user, password)){
			
			HttpSession session = request.getSession(false);
			session.setAttribute("userName", user);
			/*
			request.getRequestDispatcher("./index.jsp").forward(
					request, response);*/
			response.sendRedirect("./index.jsp");
		}else{
			request.setAttribute("msg", "Wrong user id or password");
			//response.sendRedirect("./");
			request.getRequestDispatcher("./").forward(
					request, response);
			
		}
		
		
	}
}
