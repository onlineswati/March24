package constants;

import java.io.File;

public class Init {

// Rserve variables
	public static String RSOURCEFILE;
	
// Ubuntu
	//public static final String RKILLCMD = "killall Rserve";

	public static final String LOCAL_URL = "http://localhost:8080";
//	public static final String LOCAL_URL = "http://192.168.168.154:8082";
	
	public static final String BASE_DIRECTORY = "/home"+File.separator+"ubuntu"+File.separator+"data"+File.separator+"Project";
	
	public static final String DATA_DIRECTORY = BASE_DIRECTORY+File.separator+"Input";
	
	public static final String SCRIPT_DATA_DIRECTORY = BASE_DIRECTORY+File.separator+"scripts";
	
	public static final int MAX_MEMORY_SIZE = 1024 * 1024 * 2000;
	public static final int MAX_REQUEST_SIZE = 1024 * 1024 * 2000;
	public static final String STATUS_PAGE = "/index.jsp";
	public static String SERVLET_CONTEXT_PATH;
	public static String CONTEXT_PATH;
}