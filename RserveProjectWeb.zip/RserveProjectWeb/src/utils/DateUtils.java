package utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

	private static long start;
 	private long end;
 	private final static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0");    
 	private static Date startDate;
 	private Date endDate;
 	
	public static long getTime(){
		start = System.currentTimeMillis();
        startDate = new Date(start);
        return startDate.getTime();
	}
	
	public static String getFormatedTime(long time){
		return dateFormat.format(time);
	}
}
