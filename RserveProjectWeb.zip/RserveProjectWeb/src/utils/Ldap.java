package utils;

import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

import com.novell.ldap.LDAPConnection;

public class Ldap {

	public static Properties prop = new Properties();

	static {
		try {
			InputStream inputStream=Ldap.class.getClassLoader().getResource("./config/LdapSettings.properties").openStream();
			prop.load(inputStream);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*public static void main(String[] args) {
		System.out.println(validate("test", "test1234"));
	}*/

	public static boolean validate(String user, String password) {
		
		if (StringUtils.isBlank(password) || StringUtils.isBlank(user)) {
			return false;
		}
		int ldapPort = Integer.parseInt(prop.get("ldapPort").toString());
		String ldapHost = prop.get("ldapHost").toString();
		String loginDN = "uid=" + user + "," + prop.get("base");
		int ldapVersion = Integer.parseInt(prop.get("ldapVersion").toString());
		LDAPConnection lc = new LDAPConnection();

		try {
			lc.connect(ldapHost, ldapPort);
			lc.bind(ldapVersion, loginDN, password.getBytes("UTF8"));
			lc.disconnect();
			return true;
		}catch (Exception e) {

			System.out.println("Error: " + e.toString());
			return false;
		}
	}
}
