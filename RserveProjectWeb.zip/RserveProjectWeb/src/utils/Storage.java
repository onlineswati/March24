package utils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import constants.Init;

public class Storage {

	public Storage(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}
	}
	
	private static Connection connection = null;

	public void storeDbData(Object[] data){
		try {
			Properties properties=new Properties();
			InputStream input=new FileInputStream(Init.CONTEXT_PATH);
			properties.load(input);
			connection = DriverManager.getConnection(properties.getProperty("Database.CONNECTION_URL"),properties.getProperty("Database.CONNECTION_USER"),properties.getProperty("Database.CONNECTION_PASS"));
			String insertString = "insert into " + properties.getProperty("Database.TABLE_NAME")
					+ "(batch_id, script_name, start_date, end_date, status,delete_ind,user_id)" + " values (?, ?, ?, ?, ?,?,?)";
			PreparedStatement statement = connection.prepareStatement(insertString);

			statement.setString(1, String.valueOf(data[0])); // id
			statement.setString(2, String.valueOf(data[1])); // filename
			
			
			statement.setTimestamp(3, new Timestamp((long) data[2])); // startDate
			if (data[3] != null) {
				statement.setTimestamp(4, new Timestamp((long) data[3])); // endDate
			} else {
				statement.setTimestamp(4, null);
			}
			statement.setString(5, String.valueOf(data[4])); // status
			statement.setString(6, "N"); // delete indicator
			statement.setString(7, String.valueOf(data[6])); // user

			statement.execute();
			statement.close();
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void deleteAll(String userName){
		try {
			Properties properties=new Properties();
			InputStream input=new FileInputStream(Init.CONTEXT_PATH);
			properties.load(input);
			connection = DriverManager.getConnection(properties.getProperty("Database.CONNECTION_URL"),properties.getProperty("Database.CONNECTION_USER"),properties.getProperty("Database.CONNECTION_PASS"));
			String insertString = "update " + properties.getProperty("Database.TABLE_NAME")+" set delete_ind=? Where user_id=?";
			
			PreparedStatement statement = connection.prepareStatement(insertString);
			statement.setString(1, "Y");
			statement.setString(2, userName);
			statement.execute();
			statement.close();
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void updateDbData(Object[] data){
		try {
			Properties properties=new Properties();
			InputStream input=new FileInputStream(Init.CONTEXT_PATH);
			properties.load(input);
			connection = DriverManager.getConnection(properties.getProperty("Database.CONNECTION_URL"),properties.getProperty("Database.CONNECTION_USER"),properties.getProperty("Database.CONNECTION_PASS"));
			String insertString = "update "+properties.getProperty("Database.TABLE_NAME")+" set end_date = ?, status = ? where batch_id = ?";
			PreparedStatement statement = connection.prepareStatement(insertString);
			
			statement.setTimestamp(1, new Timestamp((long) data[3])); // endDate
			statement.setString(2, String.valueOf(data[4])); // status
			//statement.setString(3, String.valueOf(data[5])); // remarks
			statement.setString(3, String.valueOf(data[0])); // id
			
			statement.execute();
			statement.close();
			connection.close();
			System.out.println();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public List<Object[]> getDbData(String userName) {

		List<Object[]> result = new ArrayList<Object[]>();

		try {
			Properties properties=new Properties();
			InputStream input=new FileInputStream(Init.CONTEXT_PATH);
			properties.load(input);
			connection = DriverManager.getConnection(properties.getProperty("Database.CONNECTION_URL"),properties.getProperty("Database.CONNECTION_USER"),properties.getProperty("Database.CONNECTION_PASS"));
//			Statement statement = connection.createStatement();
			PreparedStatement statement;
			//if(batchId.equals("all")){
				 statement = connection.prepareStatement("select * from " + properties.getProperty("Database.TABLE_NAME")+" Where delete_ind=? and user_id=?");
				 statement.setString(1, String.valueOf('N'));
				 statement.setString(2, userName);
				statement.executeQuery();
			/*}else{
				 statement = connection.prepareStatement("select * from " + properties.getProperty("Database.TABLE_NAME")+" where batch_id in (?)");
				statement.setString(1, batchId); // status
				statement.executeQuery();
			}*/
			
			ResultSet rs = statement.getResultSet();

			while (rs.next()) {
				Object[] tmpResult = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5),rs.getString(7) };
				result.add(tmpResult);
			}
			//System.out.println("get data...."+batchId);
			rs.close();
			statement.close();
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		return result;
	}

	public int getIdFromDb() {
		int result = 0;
		try {
			Properties properties=new Properties();
			InputStream input=new FileInputStream(Init.CONTEXT_PATH);
			properties.load(input);
			connection = DriverManager.getConnection(properties.getProperty("Database.CONNECTION_URL"),properties.getProperty("Database.CONNECTION_USER"),properties.getProperty("Database.CONNECTION_PASS"));
			Statement statement = connection.createStatement();

			statement.executeQuery("select max(batch_id) from " + properties.getProperty("Database.TABLE_NAME"));
			ResultSet rs = statement.getResultSet();

			while (rs.next()) {
				result = rs.getInt(1);
			}

			rs.close();
			statement.close();
			connection.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return result;
	}
}